GOR01 INVENTORY - PROYEK APK ANDROID (BUILD CLOUD)\n

Proyek ini memakai WebView Android yang memuat aplikasi inventori dari file lokal Android.
Library JavaScript (Tailwind, SheetJS/XLSX, Html5Qrcode, JsBarcode) diambil saat proses build,
lalu disimpan di APK sehingga fungsi utama dapat bekerja tanpa koneksi internet saat pemakaian.


CARA BUILD APK (perlu akun GitHub, bisa dilakukan dari HP):
1. Buat repository baru di GitHub bernama GOR01Inventory. Set repository Public agar langkah paling sederhana.
2. Upload semua file/folder dalam ZIP ini ke repository (folder android, .github, HTML sumber, README).
3. Buka tab Actions repository. Jika diminta, tekan Enable workflows.
4. Pilih workflow "Build GOR01 Android APK", tekan Run workflow, lalu Run.
5. Tunggu sampai job berwarna hijau / Completed.
6. Buka run yang selesai dan unduh artifact bernama GOR01-APK. Ekstrak ZIP artifact, ambil app-debug.apk.
7. Buka APK di Android dan izinkan pemasangan dari sumber yang diminta sistem.

Catatan: APK belum dibuat/diuji. Build pertama perlu internet di runner GitHub untuk mengunduh SDK dan pustaka JS.
ke dalam APK. Setelah berhasil dibangun, penggunaan fitur inventori dirancang offline. Scanner memerlukan izin kamera.

